export interface OllamaStore {
  models: string[]
  setModels: (models: string[]) => void
}
