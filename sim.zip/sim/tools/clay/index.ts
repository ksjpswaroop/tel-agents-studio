import { clayPopulateTool } from './populate'

export { clayPopulateTool }
