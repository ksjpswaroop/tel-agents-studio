import { chatTool } from './chat'

export const huggingfaceChatTool = chatTool
