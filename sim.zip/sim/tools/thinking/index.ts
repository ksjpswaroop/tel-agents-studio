import { thinkingTool } from './tool'

export { thinkingTool }
