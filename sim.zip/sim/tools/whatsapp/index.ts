import { sendMessageTool } from './send_message'

export const whatsappSendMessageTool = sendMessageTool
