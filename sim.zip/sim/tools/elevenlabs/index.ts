import { elevenLabsTtsTool } from './tts'

export { elevenLabsTtsTool }
