import { searchTool } from './search'

export const linkupSearchTool = searchTool
