import { promptManagerTool } from './prompt_manager'

export const autoblocksPromptManagerTool = promptManagerTool
