import { insertTool } from './insert'
import { queryTool } from './query'

export const supabaseQueryTool = queryTool
export const supabaseInsertTool = insertTool
