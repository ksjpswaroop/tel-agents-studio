import { agentTool } from './agent'
import { extractTool } from './extract'

export const stagehandExtractTool = extractTool
export const stagehandAgentTool = agentTool
