import { fileParserTool } from './parser'

export const fileParseTool = fileParserTool
