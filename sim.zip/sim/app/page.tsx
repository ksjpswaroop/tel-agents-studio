import Landing from './(landing)/landing'

export default Landing
